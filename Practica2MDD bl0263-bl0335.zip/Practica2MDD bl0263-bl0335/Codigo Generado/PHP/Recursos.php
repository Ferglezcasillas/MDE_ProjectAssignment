<html>
    <head>
    <title>
    Recursos
    </title>
    </head>
    <body bgcolor="#B8D1F1">
    

        <?php

if (!isset($_GET['varNombre'])) { //generar frontend
    
?>
       
        <form>
        <h1>Entidad Recursos</h1>

        Nombre:    <input    name="varNombre"    type="text"    value=""    ><br>
    
                
            Fabricante:    <input    name="varFabricante"    type="text"    value=""    ><br>
        
                
            HorasFuncionamiento:    <input    name="varHorasFuncionamiento"    type="text"    value=""    ><br>
        
        
        <input    type="submit"    value="Enviar"    /><br>
        </form>

    <?php
} else { //conexion mysql
    $conex = @mysql_connect("localhost", "root") or die("ERROR ...");
    mysql_select_db("webos") or die("ERROR CON LA BASE DE DATOS");
    
    
    $Fabricante          = $_GET['varFabricante'];
    $HorasFuncionamiento = $_GET['varHorasFuncionamiento'];
    $Nombre              = $_GET['varNombre'];
    
    
    $resultado = mysql_query("INSERT INTO Recursos VALUES ('$Fabricante','$HorasFuncionamiento','$Nombre')");
    
    if ($resultado)
        echo "<b>Datos insertados</b>";
    else
        echo "<b>ERROR en la insercion</b>";
    
    mysql_close();
}

?>
   </body>
    </html>
 
