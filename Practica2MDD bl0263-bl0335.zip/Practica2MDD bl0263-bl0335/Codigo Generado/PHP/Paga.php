
				<html>
				<head>
				<title>
				Paga
				</title>
				</head>
				<body bgcolor="#B8D1F1">
				<?php



if (!(count($_GET) > 0)) { //generar frontend
    
?>

				<h1>Relacion Paga</h1>

				<p>Claves primarias propagadas:<br>
				<p>CIF, ID<br>
		
				<form>

				Empresa.CIF:	<input	name="varCIF"	type="text"	value=""	><br>
				Usuario.ID:	<input	name="varID"	type="text"	value=""	><br>
	
						
					Sueldo:	<input	name="varSueldo"	type="text"	value=""	><br>
		
				
				
				<input	type="submit"	value="Enviar"	/><br>

				</form>

			<?php
} else { //conexion mysql
    $conex = @mysql_connect("localhost", "root") or die("ERROR ...");
    mysql_select_db("webos") or die("ERROR CON LA BASE DE DATOS");
    
    
    $Sueldo = $_GET['varSueldo'];
    
    $CIF = $_GET['varCIF'];
    
    $ID = $_GET['varID'];
    
    $resultado = mysql_query("INSERT INTO Paga VALUES ('$Sueldo','$CIF','$ID')");
    
    
    
    if ($resultado)
        echo "<b>Datos insertados</b>";
    else
        echo "<b>ERROR en la insercion</b>";
    
    
    
    mysql_close();
    
    
}

?>
			</body>
			</html>

		
	
	


 		