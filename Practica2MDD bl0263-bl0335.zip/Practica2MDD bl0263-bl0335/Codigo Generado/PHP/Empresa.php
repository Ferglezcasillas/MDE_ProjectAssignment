<html>
	<head>
	<title>
	Empresa
	</title>
	</head>
	<body bgcolor="#B8D1F1">
	

		<?php

if (!isset($_GET['varCIF'])) { //generar frontend
    
?>
		
		<form>
		<h1>Entidad Empresa</h1>

		CIF:	<input	name="varCIF"	type="text"	value=""	><br>
	
				
			Nombre:	<input	name="varNombre"	type="text"	value=""	><br>
		
				
			Facturacion:	<input	name="varFacturacion"	type="text"	value=""	><br>
		
		
		<input	type="submit"	value="Enviar"	/><br>
		</form>

	<?php
} else { //conexion mysql
    $conex = @mysql_connect("localhost", "root") or die("ERROR ...");
    mysql_select_db("webos") or die("ERROR CON LA BASE DE DATOS");
    
    
    $Nombre      = $_GET['varNombre'];
    $Facturacion = $_GET['varFacturacion'];
    $CIF         = $_GET['varCIF'];
    
    
    $resultado = mysql_query("INSERT INTO Empresa VALUES ('$Nombre','$Facturacion','$CIF')");
    
    if ($resultado)
        echo "<b>Datos insertados</b>";
    else
        echo "<b>ERROR en la insercion</b>";
    
    mysql_close();
}

?>
	</body>
	</html>