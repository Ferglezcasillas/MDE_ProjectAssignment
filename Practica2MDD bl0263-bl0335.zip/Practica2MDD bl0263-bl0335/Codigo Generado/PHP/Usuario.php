<html>
    <head>
    <title>
    Usuario
    </title>
    </head>
    <body bgcolor="#B8D1F1">
    

        <?php

if (!isset($_GET['varID'])) { //generar frontend
    
?>
       
        <form>
        <h1>Entidad Usuario</h1>

        ID:    <input    name="varID"    type="text"    value=""    ><br>
    
                
            Matricula:    <input    name="varMatricula"    type="text"    value=""    ><br>
        
                
            DNI:    <input    name="varDNI"    type="text"    value=""    ><br>
        
        
        <input    type="submit"    value="Enviar"    /><br>
        </form>

    <?php
} else { //conexion mysql
    $conex = @mysql_connect("localhost", "root") or die("ERROR ...");
    mysql_select_db("webos") or die("ERROR CON LA BASE DE DATOS");
    
    
    $Matricula = $_GET['varMatricula'];
    $DNI       = $_GET['varDNI'];
    $ID        = $_GET['varID'];
    
    
    $resultado = mysql_query("INSERT INTO Usuario VALUES ('$Matricula','$DNI','$ID')");
    
    if ($resultado)
        echo "<b>Datos insertados</b>";
    else
        echo "<b>ERROR en la insercion</b>";
    
    mysql_close();
}

?>
   </body>
    </html>

    